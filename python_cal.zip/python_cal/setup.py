#!/usr/bin/env python
from subprocess import call
# USAGE
# python setup.py
# python setup.py --video
# import the necessary packages
import argparse

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video")
args = vars(ap.parse_args())

# if the video argument is None, then we are reading from webcam
if args.get("video", None) is None:

	call("/Users/eric/Desktop/Work/python_cal/hellomodule");
	print "Hello! This is python, the program is finished successfully.";

# otherwise, we are reading from second webcam
else:
	call("/Users/eric/Desktop/Work/python_cal/calculator");
	print "Hello! This is python, the program is finished successfully.";



