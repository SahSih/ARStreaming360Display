#!/usr/bin/env python
from subprocess import call

call("/Users/eric/Desktop/Work/python_cal/calculator");
print "Hello! This is python, the program is finished successfully.";