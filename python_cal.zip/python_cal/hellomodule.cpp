#include <iostream>
using namespace std;



void say_hello(const char* name) {
    cout << "Hello " <<  name << ", this is C++!\n";
    
}
int main () {
	char input[20];
	cout << "Please enter your name: ";
	cin >> input;
	say_hello(input);
}
